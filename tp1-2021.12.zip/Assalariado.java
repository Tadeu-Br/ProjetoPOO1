public interface Assalariado{
    public float getSalario();
    
}